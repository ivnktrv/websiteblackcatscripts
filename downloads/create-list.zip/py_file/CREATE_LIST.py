lists = input('Напишите что нибудь - ')
file = open('LIST.txt', 'w', encoding='utf-8')
file.write(lists)
file.close()