import random

def r_p():

    while True:
        
        d = input('\nВыберите действие: +, -, x, :  - ')

        first = random.randint(0, 100)
        second = random.randint(0, 100)

        print(f'\n{first} {d} {second} = ')

r_p()