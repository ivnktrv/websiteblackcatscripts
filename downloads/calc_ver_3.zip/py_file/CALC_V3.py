def main():
    
    # пока калькулятор работает
    
    what = input('''                        ========== КАЛЬКУЛЯТОР CALC_VER-3 ==========
                        =                                          =
                        =          Продолжение - cont              =
                        =          Выход - exit                    =
                        =                                          =
                        ============================================
                        
                                      ---> ''')
    while True:
        if what == 'exit':
         # закрытие калькулятора   
            break
        
        elif what == 'cont':
            # продолжение работы
            try:
                x = float(input('\n\nВведите первое число - '))
                act = input('Выберите действие (+, -, *, /, **, //, %) - ')
                y = float(input('Введите второе число - '))

            except ValueError:
                # если введена строка а не число
                print('\nВы не ввели число!\n\n')
                continue

            try:
                if act == '+':
                    print(f'\n{x} + {y} = {x+y}\n\n')
                    i = input('''Продолжение: (c)
Выход: (e)
                              
--> ''')
                    if i == 'e':
                        break
                elif act == '-':
                    print(f'\n{x} - {y} = {x-y}\n\n')
                    i = input('''Продолжение: (c)
Выход: (e)
                              
--> ''')
                    if i == 'e':
                        break
                elif act == '*':
                    print(f'\n{x} * {y} = {x*y}\n\n')
                    i = input('''Продолжение: (c)
Выход: (e)
                              
--> ''')
                    if i == 'e':
                        break
                elif act == '/':
                    print(f'\n{x} / {y} = {x/y}\n\n')
                    i = input('''Продолжение: (c)
Выход: (e)
                              
--> ''')
                    if i == 'e':
                        break
                elif act == '**':
                    print(f'\n{x} ** {y} = {x**y}\n\n')
                    i = input('''Продолжение: (c)
Выход: (e)
                              
--> ''')
                    if i == 'e':
                        break
                elif act == '//':
                    print(f'\n{x} // {y} = {x//y}\n\n')
                    i = input('''Продолжение: (c)
Выход: (e)
                              
--> ''')
                    if i == 'e':
                        break
                elif act == '%':
                    print(f'\n{x} % {y} = {x%y}\n\n')
                    i = input('''Продолжение: (c)
Выход: (e)
                              
--> ''')
                    if i == 'e':
                        break
                else:
                    print('\nВыбрана неизвестная операция!\n\n')
                    i = input('''Продолжение: (c)
Выход: (e)
                              
--> ''')
                    if i == 'e':
                        break

            except ZeroDivisionError:
                # если возникает ошибка при делении на 0
                print(f'\n{x} / {y} = 0\n\n')
                i = input('''Продолжение: (c)
Выход: (e)
                              
--> ''')

                if i == 'e':
                    break

main()